import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router'

import { Weather } from '../weather'

@Component({
  selector: 'app-weather-report',
  templateUrl: './weather-report.component.html',
  styleUrls: ['./weather-report.component.css']
})
export class WeatherReportComponent implements OnInit {
  temp:string
  @Input() desc:string
  @Input() weather:Weather
  constructor(private route:ActivatedRoute) { 
    route.params.subscribe( (params)=>{
      this.temp = params['temp']
      this.desc = params['desc']
    } ) // an observable
  }

  ngOnInit() {
  }

}
