export class Weather{
  desc:string
  temp:number

  constructor(desc:string, temp:number){
    this.desc = desc
    this.temp = temp
  }
}