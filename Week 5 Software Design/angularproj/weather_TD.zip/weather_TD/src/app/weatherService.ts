import { Injectable } from '@angular/core';
import { Headers, Http} from '@angular/http'
// import rxjs
import 'rxjs/add/operator/toPromise'

@Injectable()
export class WeatherService {
  url:string
              // private http
  constructor (private http:Http){}

  getWeather(city:String, country:string):Promise<any> {
    // make the http.get call
    this.url = `http://api.openweathermap.org/data/2.5/weather?q=${city},${country}&APPID=48f2d5e18b0d2bc50519b58cce6409f1`
    return this.http.get(this.url)
                .toPromise()
                .then(response=>response.json() ) // implicit 'return'
                .catch(this.handleError)
  }
  // an error handler
  private handleError(error:any):Promise<any>{
    console.error('An error occured', error)
    return Promise.reject(error.message || error)

  }
}
