import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { HttpModule } from '@angular/http'
import { RouterModule, Routes, ActivatedRoute } from '@angular/router'

import { AppComponent } from './app.component';
import { FormComponent } from './form/form.component';

import { WeatherReportComponent } from './weather-report/weather-report.component';
import { WeatherHistoryComponent } from './weather-history/weather-history.component'
// declare routes
const routes:Routes = [
  {path:'report', component:WeatherReportComponent},
  {path:'history', component:WeatherHistoryComponent}
]
@NgModule({
  declarations: [
    AppComponent,
    FormComponent,
    WeatherReportComponent,
    WeatherHistoryComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
