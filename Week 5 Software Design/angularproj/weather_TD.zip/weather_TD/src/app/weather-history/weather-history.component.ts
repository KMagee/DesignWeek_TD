import { Component, OnInit, Input } from '@angular/core';
import { Weather } from '../weather'
import { ActivatedRoute } from '@angular/router'

@Component({
  selector: 'app-weather-history',
  templateUrl: './weather-history.component.html',
  styleUrls: ['./weather-history.component.css']
})
export class WeatherHistoryComponent implements OnInit {

  weatherHistory = []
  description:string
  temperature
  constructor(private route:ActivatedRoute) { 

    // check first that localStorage exists
    if(localStorage.getItem('weatherHistory')){
    let strRetrieved = localStorage.getItem('weatherHistory')
    this.weatherHistory = JSON.parse(strRetrieved)
    }
    route.params.subscribe( (params)=>{
      // params['desc']
      // params['temp']
       this.weatherHistory.push(new Weather(params['desc'], params['temp']))
       let strHistory = JSON.stringify(this.weatherHistory)
       localStorage.setItem('weatherHistory', strHistory)
    } )
  }

  ngOnInit() {
  }
}
