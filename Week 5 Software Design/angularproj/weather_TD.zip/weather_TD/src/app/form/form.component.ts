import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router'
import { Params } from '../params'
import { WeatherService } from '../weatherService'
import { Weather } from '../weather'

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css'],
  providers: [WeatherService]
})
export class FormComponent implements OnInit {
  params:Params
  weatherReport:object
  weather:Weather
  weatherHistory:Weather[] = [] // initialize as an empty array
  paramObj
  constructor(private router:Router, private weatherService:WeatherService) { 
    this.params = new Params('Dublin', 'ie')
  }

  getWeather(){
    this.weatherService.getWeather(this.params.city, this.params.country)
      .then((weatherReport)=>{
          console.log(weatherReport)
          this.weatherReport = weatherReport
          this.weather = new Weather(weatherReport.weather[0].description, Math.round(weatherReport.main.temp - 273))
          this.weatherHistory.push(this.weather)
          this.sendWeatherParams()
      })
  }

  ngOnInit(){
    this.getWeather()
  }
  sendWeatherParams(){
    let temperature = this.weather.temp
    let description = this.weather.desc
    this.router.navigate(['/report', { temp: temperature, desc: description}]);
  }

  showHistory(){
    this.router.navigate(['/history', { desc:this.weather.desc, temp:this.weather.temp}]);
  }

}
