import { Component } from '@angular/core';
import { ChildComponent } from './child/child.component'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  status:string = 'waiting...'
  timestamp:number
  category:string = 'people'
  num:string = '1'

  dd = [
  {v:"people"},
  {v:"planets"},
  {v:"species"},
  {v:"starships"}
  ]
  
  handleSwapiEvent(evt){
    this.status = evt.status
    this.timestamp = evt.timestamp
  }

}
